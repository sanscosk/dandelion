#include <algorithm>
#include <array>
#include <iterator>

#include "triangle.h"

// Triangle的构造函数
Triangle::Triangle()
{
    vertex[0] << 0, 0, 0, 1;
    vertex[1] << 0, 0, 0, 1;
    vertex[2] << 0, 0, 0, 1;
}
