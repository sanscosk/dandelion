#include <memory>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/stdout_color_sinks.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <Eigen-3.4.0/Eigen/Core>
#include <fmt/core.h>
using Eigen::Vector2d;
using Eigen::Matrix2d;

int main(){
    spdlog::set_level(spdlog::level::debug);
    
    auto console_sink = std::make_shared<spdlog::sinks::stdout_color_sink_st>();
    auto file_sink = std::make_shared<spdlog::sinks::basic_file_sink_st>("optimizer.log",true);
    spdlog::logger my_logger("fuckoptimizer", {console_sink, file_sink});
    my_logger.set_level(spdlog::level::debug);

    Vector2d x0((2211314649%827),(2211314649%1709));
    my_logger.debug("({}, {})",x0.x(),x0.y());
    Matrix2d bi;
    bi << -0.5,0,
          0,-0.5;
    Vector2d xd = bi * x0;
    Vector2d x1(1000,2000);
    double dert = 0.01;
    x1 = x0 + xd;
    //my_logger.debug("({}, {})",x1.x(),x1.y());
    while((x1-x0).norm()>=dert){
        x0 = x1;
        xd = bi * x1 ;
        x1 = x0 + xd ;
        my_logger.debug("({}, {})",x0.x(),x0.y());
    }
    my_logger.info("{}",x0.norm()*x0.norm());
    return 0;
}