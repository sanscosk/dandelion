#include "ray.h"

#include <cmath>
#include <array>
#include <iostream>
#include <Eigen/Dense>
#include <spdlog/spdlog.h>

#include "../utils/math.hpp"

using Eigen::Matrix3f;
using Eigen::Matrix4f;
using Eigen::Vector2f;
using Eigen::Vector3f;
using Eigen::Vector4f;
using std::numeric_limits;
using std::optional;
using std::size_t;

constexpr float infinity = 1e5f;
constexpr float eps      = 1e-5f;

Intersection::Intersection() : t(numeric_limits<float>::infinity()), face_index(0)
{
}

Ray generate_ray(int width, int height, int x, int y, Camera& camera, float depth)
{
    // these lines below are just for compiling and can be deleted
    (void)width;
    (void)height;
    (void)x;
    (void)y;
    (void)depth;
    // these lines above are just for compiling and can be deleted

    // The ratio between the specified plane (width x height)'s depth and the image plane's depth.

    // Transfer the view-space position to world space.
    Vector3f world_pos(0.0f, 0.0f, 0.0f);
    return {camera.position, (world_pos - camera.position).normalized()};
}

optional<Intersection> ray_triangle_intersect(const Ray& ray, const GL::Mesh& mesh, size_t index)
{
    Intersection result;
    float t;
    float u;
    float v;
    Eigen::Vector3f a = mesh.vertex(mesh.face(index)[0]);
    Eigen::Vector3f b = mesh.vertex(mesh.face(index)[1]);
    Eigen::Vector3f c = mesh.vertex(mesh.face(index)[2]);
    Eigen::Vector3f N = (b - a).cross(c - a);
    Eigen::Matrix3f A;
    A << ray.direction, a - b, a - c;
    float a1 = A.determinant();
    if (a1 > -eps && a1 < eps) {
        return std::nullopt; // 射线平行于三角形
    }
    // 求解Ax = (a - origin)的线性方程，其中x是(α, β, γ)
    Eigen::Vector3f x = A.colPivHouseholderQr().solve(a - ray.origin);
    t                 = x[0];
    u                 = x[1];
    v                 = x[2];
    // 检查t是否在有效范围内，交点在射线上
    if (t >= 0 && u >= 0 && u <= 1 && v >= 0 && v <= 1 && u + v <= 1) {
        Eigen::Vector3f P = ray.origin + t * ray.direction; // 计算交点 P
        result.t                 = t;
        result.face_index        = index;
        result.barycentric_coord = P;
        result.normal            = N.normalized();
        return result;
    }
    // 如果不在三角形内部，返回空的交点信息
    return std::nullopt;
}


std::optional<Intersection> naive_intersect(const Ray& ray, const GL::Mesh& mesh, const Matrix4f model)
{
    // 初始化一个空的交点结果
   Intersection result ;
    // 初始化一个无穷大的最小交点参数
    float closest_t = std::numeric_limits<float>::infinity();
    // 遍历网格的所有面片
    for (size_t i = 0; i < mesh.faces.count(); ++i) {
        // 获取面片的三个顶点
        Eigen::Vector3f a = mesh.vertex(mesh.face(i)[0]);
        Eigen::Vector3f b = mesh.vertex(mesh.face(i)[1]);
        Eigen::Vector3f c = mesh.vertex(mesh.face(i)[2]);
        // 对顶点进行模型变换
        a = (model * (mesh.vertex(mesh.face(i)[0])).homogeneous()).hnormalized();
        b = (model * (mesh.vertex(mesh.face(i)[1])).homogeneous()).hnormalized();
        c = (model * (mesh.vertex(mesh.face(i)[2])).homogeneous()).hnormalized();
        // 计算面片的法向量
        Eigen::Vector3f N = (b - a).cross(c - a);
        // 计算射线和平面的交点参数t
        float t = N.dot(a - ray.origin) / N.dot(ray.direction);
        // 检查t是否在有效范围内，交点在射线上
        if (t >= 0 && t < closest_t) {
            // 计算交点P
            Eigen::Vector3f P = ray.origin + t * ray.direction;
            // 计算三角形的面积
            float areaABC = 0.5f * N.norm();
            // 计算三个子三角形的面积
            float areaPBC = 0.5f * (b - P).cross(c - P).norm();
            float areaPAC = 0.5f * (a - P).cross(c - P).norm();
            float areaPAB = 0.5f * (a - P).cross(b - P).norm();
            // 计算重心坐标u, v, w
            float u = areaPBC / areaABC;
            float v = areaPAC / areaABC;
            float w = areaPAB / areaABC;
            // 判断点是否在三角形内部
            if (u >= 0 && u <= 1 && v >= 0 && v <= 1 && w >= 0 && w <= 1 && u + v + w <= 1 + eps) {
                // 更新最小交点参数
                closest_t = t;
                // 创建一个交点结果
                //result = Intersection{t, i, {u, v, w}, N.normalized()};
                closest_t                = t;
                result.t                 = t;
                result.face_index        = i;
                result.barycentric_coord = {u, v, w};
                result.normal            = N.normalized();
            }
        }
    }
    // 返回交点结果，如果没有交点，返回空的optional值
    return result;
}

